clear
close all
clc

%% Load Compensator and Send to Simulink
load("../Part 3/Lead.mat")
assignin('base', 'C', C); 
assignin('base', 'F', F); 
assignin('base', 'H', H); 

Model = "cart_pendulum";
load_system(Model);
out = sim("cart_pendulum.slx");
close_system(Model, 0)
% to see the plots open the simulink model and re-run it
