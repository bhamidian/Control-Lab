clear
close all
clc

%% Load System
load("../Part 1/System.mat")
sisotool(G_estimated)

% step(IOTransfer_r2y, [0, 10])
% save Lead.mat