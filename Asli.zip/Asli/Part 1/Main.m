clear
close all
clc

%% Part 1
Model = "cart_pendulum";
load_system(Model);
set_param(Model, 'SimMechanicsOpenEditorOnUpdate', 'off');
out = sim("cart_pendulum.slx");
close_system(Model, 0)

SR = out.StepResponce.Data;
t = out.tout;

%%%%%%% Get the Step Responce Information
SI = stepinfo(SR, t);

PO = SI.Overshoot;
ST = SI.SettlingTime;
RT = SI.RiseTime;
PT = SI.PeakTime;
FV = SR(end);

disp(['OverShoot     = ' num2str(round(PO, 2)) '  %'])
disp(['Settling Time = ' num2str(round(ST, 2)) '  s'])
disp(['Rise Time     = ' num2str(round(RT, 2)) '  s'])
disp(['Peak Time     = ' num2str(round(PT, 2)) '  s'])
disp(['Final Value   = ' num2str(round(FV, 2))])

%%%%%%%% System Identification Based on Step Info
Zeta = -log(PO/100) / sqrt(pi^2 + log(PO/100)^2);
Omega_n = pi / (PT * sqrt(1 - Zeta^2));
G_estimated = tf(Omega_n^2, [1, 2*Zeta*Omega_n, Omega_n^2]);

% to get the final value, we multiply by the final value of the actual system
G_estimated = G_estimated * FV;

% Get the Step Responce of the Estimate System and Plot on Top of Eachother
Step_estimated = step(G_estimated, t);

figure('Name', 'Estimation', 'Units', 'normalized', 'OuterPosition', [0.1, 0.1, 0.8, 0.8]);
plot(t, SR, 'k--', 'LineWidth', 2, 'DisplayName', 'Actual System'), hold on
plot(t, Step_estimated, 'b', 'LineWidth', 2, 'DisplayName', 'Estimated System')
legend('Location', 'best')
xlabel('time [s]')
title('Step Responce')
grid on
axis tight

save System.mat G_estimated