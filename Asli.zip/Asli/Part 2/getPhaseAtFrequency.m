function phase = getPhaseAtFrequency(signal, Fs, freq)
    L = length(signal);
    Y = fft(signal);
    f = Fs * (0:(L-1)) / L;
    [~, idx] = min(abs(f - freq));
    phase = angle(Y(idx));
end