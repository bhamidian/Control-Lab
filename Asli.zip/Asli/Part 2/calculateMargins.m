function [GM, PM] = calculateMargins(magnitudes, phase_differences, frequencies)
    crossover_idx = find(phase_differences <= -pi, 1); % Find -180 deg phase crossover
    GM = -20 * log10(magnitudes(crossover_idx)); % Gain Margin in dB
    gain_crossover_idx = find(magnitudes <= 1, 1); % Find unity-gain magnitude crossover
    PM = (phase_differences(gain_crossover_idx) + pi) * (180 / pi); % Phase Margin in degrees
end