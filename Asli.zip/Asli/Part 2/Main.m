clear
close all
clc

%% Part 2
Model = "cart_pendulum";
load_system(Model);
set_param(Model, 'SimMechanicsOpenEditorOnUpdate', 'off');

FreqList = logspace(-1, 2, 20); 

Mags = zeros(size(FreqList));
PhaseDiff = zeros(size(FreqList));

for i = 1:length(FreqList)
    FreqVar = FreqList(i); 
    assignin('base', 'FreqVar', FreqVar); 

    % Run the Simulink model
    simOut = sim(Model, 'ReturnWorkspaceOutputs', 'on');
    tout = simOut.tout; % Time vector
    OutputSignal = simOut.OutputSignal.Data;

    % Get the Last 50 seconds of data
    phase_diff = getPhaseAtFrequency(OutputSignal, 1/(tout(3) - tout(2)), FreqVar);
    mag = max(OutputSignal(tout>50));
    
    Mags(i) = mag;
    PhaseDiff(i) = phase_diff;
end

% Unwrap phase to correct abrupt phase jumps
PhaseDiff = unwrap(PhaseDiff);

[GM, PM] = calculateMargins(Mags, PhaseDiff, FreqList);

% Display results
fprintf('Gain Margin (GM): %.2f dB\n', GM);
fprintf('Phase Margin (PM): %.2f degrees\n', PM);

close_system(Model, 0)