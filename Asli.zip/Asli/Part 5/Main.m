clear
close all
clc

%% Load System
load("../Part 1/System.mat")
pidTuner(G_estimated)

% save PID.mat