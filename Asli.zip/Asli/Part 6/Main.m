clear
close all
clc

%% Load Compensator and Send to Simulink
load("../Part 5/PID.mat")
assignin('base', 'C', C); 
assignin('base', 'G', G_estimated); 

Model = "cart_pendulum";
load_system(Model);
out = sim("cart_pendulum.slx");
close_system(Model, 0)
% to see the plots open the simulink model and re-run it
